var config = {
    apiKey: "AIzaSyAyWdgJ_a-yvH2EaDOKhILIuLvqkhtsIKM",
    authDomain: "ytdemo3-bee16.firebaseapp.com",
    databaseURL: "https://ytdemo3-bee16.firebaseio.com",
    projectId: "ytdemo3-bee16",
    storageBucket: "ytdemo3-bee16.appspot.com",
    messagingSenderId: "187839479436"
  };
  firebase.initializeApp(config);

var database = firebase.database();
var number = 0;
var user = Math.floor((Math.random() * 1000000) + 1);
var userString = user.toString(8) + "/";


function writeUserData(userId, name, email, imageUrl) {
  firebase.database().ref(userString + userId).set({
    username: name,
    email: email,
    profile_picture : imageUrl
  });
}
var globalURL = "";
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete') {
	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
	var url = tabs[0].url;
	if (url.includes("www.youtube.com/watch?") && (globalURL != url || glovalURL == "")) {
		number = number + 1;
    	writeUserData(number, "pete", url, "google.com");
    	globalURL = url;
    }

});
  }
})

