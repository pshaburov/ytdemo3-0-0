//
//  ViewController.swift
//  YTDemo-Simulator-3.0
//
//  Created by Peter Shaburov on 4/12/19.
//  Copyright © 2019 Peter Shaburov. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase
class ViewController: UIViewController {
    let videoList: [String]  = []
    override func viewDidLoad() {
        super.viewDidLoad()
       startTimer()
    }
    weak var timer: Timer?

    
    func startTimer() {
        timer?.invalidate()   // just in case you had existing `Timer`, `invalidate` it before we lose our reference to it
        timer = Timer.scheduledTimer(withTimeInterval: 3600, repeats: true) { [weak self] _ in
            self!.deleteData()
            self!.fetchVideoList()
        }
    }
    
    func stopTimer() {
        timer?.invalidate()
    }
    
    // if appropriate, make sure to stop your timer in `deinit`
    
    deinit {
        stopTimer()
    }
    
    var first: [(key: String, value: Int)] = []
    func orderTheLinks(links: [String]) {
        var counts:[String:Int] = [:]
        var mutableLinks = links
        for item in mutableLinks {
            counts[item] = (counts[item] ?? 0) + 1
        }
        writeData(links:counts)
    }
    func writeData(links: [String:Int]) {
        let youtuberef = Database.database().reference().child("First/")
        first = ((links.sorted(by: <)))
        if first.count < 100 {
            for i in 0...first.count - 1 {
                youtuberef.childByAutoId().setValue(first[i].key)
            }
        } else {
            for i in 0...100 {
                youtuberef.childByAutoId().setValue(first[i].key)
            }
        }
    }
    func deleteData() {
        let youtuberef = Database.database().reference().child("First/")
        youtuberef.removeValue()
    }
    func fetchVideoList() {
        self.observeFirebase { [unowned self] (runData) in
            self.orderTheLinks(links: self.links)
        }
        
    }
    var links: [String] = []
    func observeFirebase(completion: @escaping ([String:AnyObject]?) -> ()) {
        let ref = Database.database().reference().child("Youtube")
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            let dataRun = snapshot.value as?  [String:AnyObject]
          
            for (key, _) in dataRun! {
                self.links.append(dataRun![key]!["link"] as! String)
            }
            completion((dataRun))
        })
    }

}

